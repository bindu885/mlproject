# Tutorial Models [Archived]

Warning: This code is no longer tested or maintained.

This folder contains the old
[tensorflow/models tutorials](https://github.com/tensorflow/models/tree/master/tutorials)
directory.

These tutorials were featured on
[TensorFlow.org](https://www.tensorflow.org/tutorials/)
Until the site switched to TF2. The descriptive text for these tutorials can be
found in the
[tensorflow/docs r1](https://github.com/tensorflow/docs/tree/master/site/en/r1)
directory.


